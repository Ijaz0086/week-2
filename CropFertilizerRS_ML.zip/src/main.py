from crop_recommendation import predict_crop
from fertilizer_recommendation import recommend_fertilizer

def main():
    print("Crop & Fertilizer Recommendation System")
    soil_data = {'N': 40, 'P': 50, 'K': 30, 'temperature': 26.5, 'humidity': 80, 'ph': 6.5, 'rainfall': 200}
    crop = predict_crop(soil_data)
    fertilizer = recommend_fertilizer(soil_data['N'], soil_data['P'], soil_data['K'])
    print(f"Recommended Crop: {crop}")
    print(f"Fertilizer Recommendation: {fertilizer}")

if __name__ == "__main__":
    main()
