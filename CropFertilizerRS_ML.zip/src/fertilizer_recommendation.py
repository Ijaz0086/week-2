def recommend_fertilizer(N, P, K):
    optimal = {'N': 120, 'P': 60, 'K': 40}
    return {nutrient: max(0, optimal[nutrient] - value) for nutrient, value in zip(['N', 'P', 'K'], [N, P, K])}
