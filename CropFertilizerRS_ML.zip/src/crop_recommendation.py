import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import pickle

def predict_crop(soil_data):
    model = pickle.load(open('models/crop_model.pkl', 'rb'))
    features = [[soil_data['N'], soil_data['P'], soil_data['K'], soil_data['temperature'], soil_data['humidity'], soil_data['ph'], soil_data['rainfall']]]
    return model.predict(features)[0]
