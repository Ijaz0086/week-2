# Crop & Fertilizer Recommendation System using ML

This project predicts the best crops for farming and suggests fertilizers based on soil and weather conditions.

## Features
- **Crop Prediction**: Uses ML (Random Forest) to recommend crops.
- **Fertilizer Suggestion**: Suggests nutrient requirements.

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run: `python src/main.py`

## Example
**Input:** `N=40, P=50, K=30, Temp=26.5, Humidity=80, pH=6.5, Rainfall=200`  
**Output:** `Recommended Crop: Rice, Fertilizer: {'N': 80, 'P': 10, 'K': 10}`
